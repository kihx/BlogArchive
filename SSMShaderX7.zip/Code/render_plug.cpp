//--------------------------------------------------------------------------------------
// File: render_plug.cpp
//
// Real-Time Subsurface Scattering using Shadow Maps, ShaderX7
// (c) 2007-2009 Hyunwoo Ki. http://ki-h.com/
//
//--------------------------------------------------------------------------------------


#include "dxstdafx.h"
#include "render_plug.h"
#include "obj.h"
#include "BSSRDF.h"
#include "util.h"

//#define _PERFORMANCE_TEST


//===============================================
// Extern Variables
//===============================================
extern ID3DXEffect* g_pEffect;
extern CDXUTDialog g_HUD, g_SampleUI1, g_SampleUI2;

extern bool g_bShowHelp;
extern bool g_bShowUI;
extern int g_nMaterialType;


//===============================================
// Global Variables
//===============================================
D3DVIEWPORT9 g_ViewPortFrameBuffer;
D3DVIEWPORT9 g_ViewPortSSM = {0,0,SSM_WIDTH, SSM_WIDTH, 0.0f, 1.0f};
LPDIRECT3DSURFACE9 g_DepthStencilSSM = NULL;
LPDIRECT3DSURFACE9 g_DepthStencilFrameBuffer = NULL;
LPDIRECT3DTEXTURE9 g_pTextureSSM0;		// transmitted irradiance
LPDIRECT3DTEXTURE9 g_pTextureSSM1;		// world position / material ID
LPDIRECT3DTEXTURE9 g_pTextureSSM2;		// normal / depth
LPDIRECT3DTEXTURE9 g_pRandomTexture = NULL;

OBJmodel *g_objBG = NULL, *g_objModel = NULL;
OBJmodel *g_objAnimation[59];
bool g_bAnimation = false;
int g_nCurrentFrame = 0;

const int  MATERIAL_COUNT	 = 8;
OpticalProperty g_OpticalProperties[MATERIAL_COUNT];

double g_fTimeConsume[3];		// performance test


extern void RenderText( );


//-------------------------------------------------//
#include "render_scene.h"
//-------------------------------------------------//


// create non-d3d resources & init
int	RenderInit( )
{
	return 0;
};


int	RenderQuit( )
{
	return 0;
};


void LoadScene( IDirect3DDevice9* pD3DDevice )
{
	static int currentScene = -1;
	extern int g_nScene;

	if ( currentScene == g_nScene )
		return;

	// Destroy models
	SAFE_DELETE( g_objBG );
	SAFE_DELETE( g_objModel );

	for ( int i = 0; i < 59; ++i )
	{
		SAFE_DELETE( g_objAnimation[i] );
	}

	g_bAnimation = false;


	// Load models
	switch ( g_nScene )
	{
	case 0:
		g_objBG = NULL;

		g_objModel = new OBJmodel( );
		g_objModel->readOBJ( "./data/tweety.obj" );
		g_objModel->scaleIsotropic( 15.0f );
		g_objModel->buildVertexBuffer( pD3DDevice, RENDER_SMOOTH_SHADED | RENDER_MATERIAL | RENDER_TEXTURE_COORDS );
		break;

	case 1:
		g_objBG = NULL;

		g_objModel = new OBJmodel( );
		g_objModel->readOBJ( "./data/head_big_ears.obj" );
		g_objModel->scaleIsotropic( 14.0f );
		g_objModel->buildVertexBuffer( pD3DDevice, RENDER_SMOOTH_SHADED | RENDER_MATERIAL | RENDER_TEXTURE_COORDS );
		break;

	case 2:
		g_objBG = NULL;

		g_objModel = new OBJmodel( );
		g_objModel->readOBJ( "./data/bun_zipper.obj" );
		g_objModel->scaleIsotropic( 13.0f );
		g_objModel->buildVertexBuffer( pD3DDevice, RENDER_SMOOTH_SHADED | RENDER_MATERIAL | RENDER_TEXTURE_COORDS );
		break;

	case 3:
		g_objBG = NULL;

		g_objModel = new OBJmodel( );
		g_objModel->readOBJ( "./data/femailhead.obj" );
		g_objModel->scaleIsotropic( 14.0f );
		g_objModel->buildVertexBuffer( pD3DDevice, RENDER_SMOOTH_SHADED | RENDER_MATERIAL | RENDER_TEXTURE_COORDS );
		break;

	case 4:
		g_objBG = NULL;

		g_objModel = new OBJmodel( );
		g_objModel->readOBJ( "./data/maxplanck.obj" );
		g_objModel->scaleIsotropic( 16.0f );
		g_objModel->buildVertexBuffer( pD3DDevice, RENDER_SMOOTH_SHADED | RENDER_MATERIAL | RENDER_TEXTURE_COORDS );
		break;

	case 5:
		g_bAnimation = true;

//		g_objBG = NULL;
 		g_objBG = new OBJmodel( );
 		g_objBG->readOBJ( "./data/bigguy/ground.obj" );
 		g_objBG->scaleIsotropic( 13.0f );
 		g_objBG->scaleTranslate( 1.0f, 0.0f, -3.5f, 0.0f );
 		g_objBG->buildVertexBuffer( pD3DDevice, RENDER_SMOOTH_SHADED | RENDER_MATERIAL | RENDER_TEXTURE_COORDS );

		g_objModel = NULL;

		char buff[50];
		for ( int i = 0; i < 59; ++i )
		{
			g_objAnimation[i] = new OBJmodel( );
			sprintf( buff, "./data/bigguy/bigguy_%02d.obj", i );
			g_objAnimation[i]->readOBJ( buff );
			g_objAnimation[i]->scaleIsotropic( 9.0f );
			g_objAnimation[i]->buildVertexBuffer( pD3DDevice, RENDER_SMOOTH_SHADED | RENDER_MATERIAL | RENDER_TEXTURE_COORDS );
		}
		break;
	}

	currentScene = g_nScene;
}


// create D3DPOOL_MANAGED resources
int RenderCreateResource( IDirect3DDevice9* pD3DDevice )
{
	HRESULT hr;

	LoadScene( pD3DDevice );

	return 0;
};


// destroy D3DPOOL_MANAGED resources
int RenderDestroyResource( )
{
	SAFE_RELEASE( g_pEffect );

	SAFE_DELETE( g_objBG );
	SAFE_DELETE( g_objModel );	

	for ( int i = 0; i < 59; ++i )
	{
		SAFE_DELETE( g_objAnimation[i] );
	}

	return 0;
};


// create D3DPOOL_DEFAULT resources
int RenderResetResource( IDirect3DDevice9* pD3DDevice )
{
	HRESULT hr;

	if ( g_pEffect ) 
		g_pEffect->OnResetDevice( );


	// uniform for LOD level computation
	D3DXVECTOR2 res;
	pD3DDevice->GetViewport( &g_ViewPortFrameBuffer );
	res.x = g_ViewPortFrameBuffer.Width;
	res.y = g_ViewPortFrameBuffer.Height;
	V_RETURN( g_pEffect->SetValue( "g_vResolution", &res, sizeof( D3DXVECTOR2 ) ) );

	// create depth/stencil surface
	V_RETURN( pD3DDevice->GetDepthStencilSurface( &g_DepthStencilFrameBuffer ) );
	V_RETURN( pD3DDevice->CreateDepthStencilSurface( SSM_WIDTH, SSM_WIDTH, D3DFMT_D16, D3DMULTISAMPLE_NONE, 0, TRUE, &g_DepthStencilSSM, NULL ) );

	// create textures/render targets ( allocate render target as early as possible )
	V( D3DXCreateTexture( pD3DDevice, SSM_WIDTH, SSM_WIDTH, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A16B16G16R16F, D3DPOOL_DEFAULT, &g_pTextureSSM0 ) );
	V( D3DXCreateTexture( pD3DDevice, SSM_WIDTH, SSM_WIDTH, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A16B16G16R16F, D3DPOOL_DEFAULT, &g_pTextureSSM1 ) );
	V( D3DXCreateTexture( pD3DDevice, SSM_WIDTH, SSM_WIDTH, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A16B16G16R16F, D3DPOOL_DEFAULT, &g_pTextureSSM2 ) );

	// create random texture
	CreateRandomTexture( pD3DDevice );

	// set material properties
	for ( int i = 0; i < MATERIAL_COUNT; ++i )
	{
		g_OpticalProperties[i].SetProperty( pD3DDevice, i );
	}

	return 0;
};


// destroy D3DPOOL_DEFAULT resources
int RenderLostResource( )
{
	if ( g_pEffect ) 
		g_pEffect->OnLostDevice( );

	SAFE_RELEASE( g_DepthStencilSSM );

	SAFE_RELEASE( g_pTextureSSM0 );
	SAFE_RELEASE( g_pTextureSSM1 );
	SAFE_RELEASE( g_pTextureSSM2 );

	SAFE_RELEASE( g_pRandomTexture );

	for ( int i = 0; i < MATERIAL_COUNT; ++i )
	{
		g_OpticalProperties[i].CleanUp( );
	}

	return 0;
};


// render/move frame callbacks
int RenderFrameMove( IDirect3DDevice9* pD3DDevice, double fTime, float fElapsedTime )
{	
	g_nCurrentFrame = fmod( fTime * 20.0, 59.0 );

	if ( g_nCurrentFrame > 58 )
		g_nCurrentFrame = 0;

	return 0;
};


int RenderFrameRender( IDirect3DDevice9* pD3DDevice, double fTime, float fElapsedTime )
{
	HRESULT hr;
	UINT nPasses;

	LPDIRECT3DSURFACE9 lpBackBuffer;
	pD3DDevice->GetRenderTarget( 0, &lpBackBuffer );


	// check if we want to load another scene
	LoadScene( pD3DDevice );

	// check for updates
	CheckPositionUpdates( );


	// render begine
	pD3DDevice->BeginScene( );


	//=====================================================	
	// PASS 1: Create SSMs ( Irradiance, Position/MaterialID, Normal/Depth )
	//=====================================================
	if ( g_bUpdateSSM )
	{
#ifdef _PERFORMANCE_TEST		// for performance test
		LARGE_INTEGER freq;
		QueryPerformanceFrequency( &freq );
		LARGE_INTEGER dwStart, dwEnd;
		QueryPerformanceCounter( &dwStart );
#endif

		LPDIRECT3DSURFACE9	pSurfaceSSM0, pSurfaceSSM1, pSurfaceSSM2;

		V( g_pTextureSSM0->GetSurfaceLevel( 0, &pSurfaceSSM0 ) );
		V( g_pTextureSSM1->GetSurfaceLevel( 0, &pSurfaceSSM1 ) );
		V( g_pTextureSSM2->GetSurfaceLevel( 0, &pSurfaceSSM2 ) );

		V( pD3DDevice->SetRenderTarget( 0, pSurfaceSSM0 ) );
		V( pD3DDevice->SetRenderTarget( 1, pSurfaceSSM1 ) );
		V( pD3DDevice->SetRenderTarget( 2, pSurfaceSSM2 ) );

		V( pD3DDevice->SetDepthStencilSurface( g_DepthStencilSSM ) );

		V( pD3DDevice->SetViewport( &g_ViewPortSSM ) );

		pD3DDevice->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0x00000000, 1.0f, 0 );

		g_pEffect->SetTechnique( "CreateSSM" );

		RenderSceneLightView( pD3DDevice );

		//V( g_DepthStencilSSM->Release( ) );
		V( pSurfaceSSM0->Release( ) );
		V( pSurfaceSSM1->Release( ) );
		V( pSurfaceSSM2->Release( ) );

#ifdef _PERFORMANCE_TEST
		QueryPerformanceCounter( &dwEnd );
		LONGLONG distance = dwEnd.QuadPart - dwStart.QuadPart;
		double cps = 1.0 / double( freq.QuadPart );
		double time = distance * cps * 1000.0;		
		g_fTimeConsume[0] = time;
#endif
	}


	//=====================================================
	// PASS 2: Compute local & subsurface scattered illumination
	//=====================================================
	{
#ifdef _PERFORMANCE_TEST		// for performance test
		LARGE_INTEGER freq;
		QueryPerformanceFrequency( &freq );
		LARGE_INTEGER dwStart, dwEnd;
		QueryPerformanceCounter( &dwStart );
#endif

		g_pEffect->SetTexture( "SSM0", g_pTextureSSM0 );
		g_pEffect->SetTexture( "SSM1", g_pTextureSSM1 );
		g_pEffect->SetTexture( "SSM2", g_pTextureSSM2 );

		V( pD3DDevice->SetRenderTarget( 0, lpBackBuffer ) );
		V( pD3DDevice->SetRenderTarget( 1, NULL ) );
		V( pD3DDevice->SetRenderTarget( 2, NULL ) );

		V( pD3DDevice->SetDepthStencilSurface( g_DepthStencilFrameBuffer ) );

		V( pD3DDevice->SetViewport( &g_ViewPortFrameBuffer ) );

		pD3DDevice->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0x00000000, 1.0f, 0 );

		g_pEffect->SetTechnique( "ComputeIllumination" );

		RenderScene( pD3DDevice );

		V( g_DepthStencilFrameBuffer->Release( ) );
		V( lpBackBuffer->Release( ) );


#ifdef _PERFORMANCE_TEST
		QueryPerformanceCounter( &dwEnd );
		LONGLONG distance = dwEnd.QuadPart - dwStart.QuadPart;
		double cps = 1.0 / double( freq.QuadPart );
		double time = distance * cps * 1000.0;
		g_fTimeConsume[1] = time;
#endif
	}



	//=====================================================
	// Debugging 
	//=====================================================
	extern int g_nDebugTexture;

	if ( g_nDebugTexture != 0 )
	{
		float sRGB = 1.0f, sA = 0.0f;
		switch ( g_nDebugTexture )
		{
		case 1:
			g_pEffect->SetTexture( "DEBUGTEX", g_pTextureSSM0 );		// irradiance light view
			break;
		case 2:
			g_pEffect->SetTexture( "DEBUGTEX", g_pTextureSSM1 );		// position light view
			break;
		case 3:
			g_pEffect->SetTexture( "DEBUGTEX", g_pTextureSSM1 );		// material id light view
			sRGB = 0.0f; sA = 1.0f;
			break;
		case 4:
			g_pEffect->SetTexture( "DEBUGTEX", g_pTextureSSM2 );		// normal light view
			break;
		case 5:
			g_pEffect->SetTexture( "DEBUGTEX", g_pTextureSSM2 );		// depth light view
			sRGB = 0.0f; sA = 1.0f;
			break;
		}

		g_pEffect->SetValue( "g_fDebugScaleRGB", &sRGB, sizeof( float ) );
		g_pEffect->SetValue( "g_fDebugScaleAlpha", &sA, sizeof( float ) );

		g_pEffect->SetTechnique( "DebugTechnique" );

		g_pEffect->Begin( &nPasses, 0 );

		for ( UINT p = 0; p < nPasses; p++ )
		{
			g_pEffect->BeginPass( p );
			RenderScreenQuad( pD3DDevice );
			g_pEffect->EndPass( );
		}

		g_pEffect->End( );
	}


	g_bUpdateCamera = g_bUpdateSSM = false;


	//	DXUT_BeginPerfEvent( DXUT_PERFEVENTCOLOR, L"HUD / Stats" ); // These events are to help PIX identify what the code is doing

	if ( g_bShowHelp )
	{
		RenderText( );
	}

	if ( g_bShowUI )
	{
		V( g_HUD.OnRender( fElapsedTime ) );
		V( g_SampleUI1.OnRender( fElapsedTime ) );
		V( g_SampleUI2.OnRender( fElapsedTime ) );
	}

	//	DXUT_EndPerfEvent( );


	pD3DDevice->EndScene( );

	return 0;
};


#define RANDOM_WIDTH		2048
D3DXVECTOR4 g_randdata[RANDOM_WIDTH][RANDOM_WIDTH];
void CreateRandomTexture( IDirect3DDevice9* pD3DDevice )
{
	HRESULT hr;
	D3DLOCKED_RECT lockedRect;
	D3DXVECTOR4 *bitData = NULL;

	srand( timeGetTime( ) );
	for ( int i = 0; i < RANDOM_WIDTH; i++ )
	{
		for ( int j = 0; j < RANDOM_WIDTH; j++ )
		{
			g_randdata[i][j].x = genrand_real2( ) - 0.5f;	//float( rand( ) ) / float( RAND_MAX );
			g_randdata[i][j].y = genrand_real2( ) - 0.5f;	//float( rand( ) ) / float( RAND_MAX );
			g_randdata[i][j].z = genrand_real2( ) - 0.5f;	//float( rand( ) ) / float( RAND_MAX );
			g_randdata[i][j].w = genrand_real2( ) - 0.5f;	//float( rand( ) ) / float( RAND_MAX );
		}
	}

	V( D3DXCreateTexture( pD3DDevice, RANDOM_WIDTH, RANDOM_WIDTH, 1, D3DUSAGE_DYNAMIC, D3DFMT_A32B32G32R32F, D3DPOOL_DEFAULT, &g_pRandomTexture ) );

	V( g_pRandomTexture->LockRect( 0, &lockedRect, NULL, D3DLOCK_DISCARD ) );

	bitData = ( D3DXVECTOR4* ) lockedRect.pBits;

	memcpy( bitData, g_randdata, sizeof( D3DXVECTOR4 )*RANDOM_WIDTH*RANDOM_WIDTH );

	V( g_pRandomTexture->UnlockRect( 0 ) );

	g_pEffect->SetTexture( "RANDOMTEX", g_pRandomTexture );
}