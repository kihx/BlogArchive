
#include "dxstdafx.h"



extern void MakeDipoleDiffusionReflectanceTexture( IDirect3DDevice9* pD3DDevice, LPDIRECT3DTEXTURE9 pDipoleTexture );


class OpticalProperty
{
public:
	float ID;
	float MeanCosineAngle;
	D3DXVECTOR3 Absorption;
	D3DXVECTOR3 ReducedScattering;
	D3DXVECTOR3 ScatteringCoefficient;
	D3DXVECTOR3 ExtinctionCoefficient;
	D3DXVECTOR3 MeanFreePath;
	D3DXVECTOR3 EffectiveExtinction;
	D3DXVECTOR3 F0;
	D3DXVECTOR3 DiffuseReflectance;
	D3DXVECTOR3 Eta, EtaInverse, EtaRsq;


public:
	void CleanUp( )
	{
	}

	void Commit( ID3DXEffect* pEffect )
	{
		HRESULT hr;

		D3DXVECTOR4 diffuse( DiffuseReflectance, 1.0f );
		V( pEffect->SetVector( "g_vDiffuseReflectance", &diffuse ) );

		V( pEffect->SetValue( "g_vScatteringCoefficient", &ScatteringCoefficient, sizeof( D3DXVECTOR3 ) ) );
		V( pEffect->SetValue( "g_vExtinctionCoefficient", &ExtinctionCoefficient, sizeof( D3DXVECTOR3 ) ) );
		V( pEffect->SetValue( "g_vMeanFreePath", &MeanFreePath, sizeof( D3DXVECTOR3 ) ) );
		V( pEffect->SetValue( "g_vEta", &Eta, sizeof( D3DXVECTOR3 ) ) );
		V( pEffect->SetValue( "g_vEtaInverse", &EtaInverse, sizeof( D3DXVECTOR3 ) ) );
		V( pEffect->SetValue( "g_vEtaRsq", &EtaRsq, sizeof( D3DXVECTOR3 ) ) );
		V( pEffect->SetValue( "g_vF0", &F0, sizeof( D3DXVECTOR3 ) ) );
	}


	void SetProperty( IDirect3DDevice9* pD3DDevice, int material )
	{
		switch ( material )
		{
		case 0:	// skimmilk
			ReducedScattering = D3DXVECTOR3( 2.55f, 3.21f, 3.77f );
			Absorption = D3DXVECTOR3( 0.0011f, 0.0024f, 0.014f );
			DiffuseReflectance = D3DXVECTOR3( 0.91f, 0.88f, 0.76f );

			Eta = D3DXVECTOR3( 1.3f, 1.3f-0.02f, 1.3f+( -0.02f*2.0f ) );
			EtaInverse = D3DXVECTOR3( 1.0f/1.3f, 1.0f/( 1.3f-0.02f ), 1.0f/( 1.3f+( -0.02f*2.0f ) ) );			
			break;

		case 1:	// apple
			ReducedScattering = D3DXVECTOR3( 2.29f, 2.39f, 1.97f );
			Absorption = D3DXVECTOR3( 0.003f, 0.0034f, 0.046f );
			DiffuseReflectance = D3DXVECTOR3( 0.86f, 0.86f, 0.53f );

			Eta = D3DXVECTOR3( 1.3f, 1.3f-0.02f, 1.3f+( -0.02f*2.0f ) );
			EtaInverse = D3DXVECTOR3( 1.0f/1.3f, 1.0f/( 1.3f-0.02f ), 1.0f/( 1.3f+( -0.02f*2.0f ) ) );
			break;

		case 2:	// potato
			ReducedScattering = D3DXVECTOR3( 0.68f, 0.70f, 0.55f );
			Absorption = D3DXVECTOR3( 0.0024f, 0.009f, 0.12f );
			DiffuseReflectance = D3DXVECTOR3( 0.77f, 0.62f, 0.21f );

			Eta = D3DXVECTOR3( 1.3f, 1.3f-0.02f, 1.3f+( -0.02f*2.0f ) );
			EtaInverse = D3DXVECTOR3( 1.0f/1.3f, 1.0f/( 1.3f-0.02f ), 1.0f/( 1.3f+( -0.02f*2.0f ) ) );
			break;

		case 3:	// marble
			ReducedScattering = D3DXVECTOR3( 2.19f, 2.62f, 3.00f );
			Absorption = D3DXVECTOR3( 0.0021f, 0.0041f, 0.0071f );
			DiffuseReflectance = D3DXVECTOR3( 0.83f, 0.79f, 0.75f );

			Eta = D3DXVECTOR3( 1.5f, 1.5f-0.02f, 1.5f+( -0.02f*2.0f ) );
			EtaInverse = D3DXVECTOR3( 1.0f/1.5f, 1.0f/( 1.5f-0.02f ), 1.0f/( 1.5f+( -0.02f*2.0f ) ) );
			break;			

		case 4:	// synthetic ( half albedo )
			ReducedScattering = D3DXVECTOR3( 1.0f, 1.15f, 1.3f );
			Absorption = D3DXVECTOR3( 1.0f, 1.15f, 1.3f );
			DiffuseReflectance = D3DXVECTOR3( 1.0f, 0.95f, 0.9f );

			Eta = D3DXVECTOR3( 1.3f, 1.3f, 1.3f );
			EtaInverse = D3DXVECTOR3( 1.0f/1.3f, 1.0f/1.3f, 1.0f/1.3f );
			break;			
		}

		ScatteringCoefficient = ReducedScattering / ( 1.0f - MeanCosineAngle );
		ExtinctionCoefficient = Absorption + ScatteringCoefficient;
		MeanFreePath.x = 1.0f / ExtinctionCoefficient.x;
		MeanFreePath.y = 1.0f / ExtinctionCoefficient.y;
		MeanFreePath.z = 1.0f / ExtinctionCoefficient.z;
		EtaRsq = D3DXVECTOR3( ( 1.0f/Eta.x )*( 1.0f/Eta.x ), ( 1.0f/Eta.y )*( 1.0f/Eta.y ), ( 1.0f/Eta.z )*( 1.0f/Eta.z ) );

		F0.x = ( ( Eta.x - 1.0f )*( Eta.x - 1.0f ) ) / ( ( Eta.x + 1.0f )*( Eta.x + 1.0f ) );
		F0.y = ( ( Eta.y - 1.0f )*( Eta.y - 1.0f ) ) / ( ( Eta.y + 1.0f )*( Eta.y + 1.0f ) );
		F0.z = ( ( Eta.z - 1.0f )*( Eta.z - 1.0f ) ) / ( ( Eta.z + 1.0f )*( Eta.z + 1.0f ) );
	}
};