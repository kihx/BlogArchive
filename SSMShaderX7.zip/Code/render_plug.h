
#pragma once

#ifndef RENDER_PLUG_H
#define RENDER_PLUG_H


// the size of the sub-scatter maps
#define	SSM_WIDTH		1024
#define	SSM_HEIGHT		SSM_WIDTH


// create non-d3d resources & init
extern int RenderInit( );
extern int RenderQuit( );

// create/destroy D3DPOOL_MANAGED resources
extern int RenderCreateResource( IDirect3DDevice9* pD3DDevice );
extern int RenderDestroyResource( );

// create/destroy D3DPOOL_DEFAULT resources
extern int RenderResetResource( IDirect3DDevice9* pD3DDevice );
extern int RenderLostResource( );

// render/move frame callbacks
extern int RenderFrameMove( IDirect3DDevice9* pD3DDevice, double fTime, float fElapsedTime );
extern int RenderFrameRender( IDirect3DDevice9* pD3DDevice, double fTime, float fElapsedTime );

void CreateRandomTexture( IDirect3DDevice9* pD3DDevice );

#endif