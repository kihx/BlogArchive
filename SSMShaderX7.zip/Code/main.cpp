//--------------------------------------------------------------------------------------
// File: main.cpp
//
// Real-Time Subsurface Scattering using Shadow Maps, ShaderX7
// (c) 2007-2009 Hyunwoo Ki. http://ki-h.com/
//
//--------------------------------------------------------------------------------------


#include "dxstdafx.h"
#include "resource.h"
#include "render_plug.h"
#include "BSSRDF.h"


#pragma warning( disable: 4244 )
#pragma warning( disable: 4311 )
#pragma warning( disable: 4305 )


//--------------------------------------------------------------------------------------
// Global variables
//--------------------------------------------------------------------------------------
IDirect3DDevice9*	g_pD3DDevice = NULL;
ID3DXFont* g_pFont = NULL; // Font for drawing text
ID3DXSprite* g_pTextSprite = NULL; // Sprite for batching draw text calls
ID3DXEffect* g_pEffect = NULL; // D3DX effect interface
CModelViewerCamera g_Camera; // A model viewing camera
CModelViewerCamera g_Light; // A model viewing camera
CDXUTDialogResourceManager g_DialogResourceManager; // manager for shared resources of dialogs
CD3DSettingsDlg g_SettingsDlg; // Device settings dialog
CDXUTDialog g_HUD; // dialog for standard controls
CDXUTDialog g_SampleUI1; // dialog for sample specific controls
CDXUTDialog	g_SampleUI2;

// GUI
bool g_bAlwaysUpdate = false;
int g_nMaterialType = 3;
bool g_bShowHelp = true;
bool g_bShowUI = true;
int g_nActiveLight = 0;
bool g_bToggleLightMoving = false;

// Uniforms
float g_fLocalDiffuse = 0.2f, g_fLocalSpecular = 0.15f, g_fSingleScattering = 1.2f, g_fRotation = 0.0f;
float g_fOpticalScaling = 10.0f, g_fOpticalBias = 0.0f, g_fMeanCosineAngle = 0.0f;
float g_fJitter = 0.1f, g_fPenumbra = 0.85f;
int	 g_nSamples = 15, g_nScene = 0, g_nDebugTexture = 0;
D3DXVECTOR3 g_vDiffuseReflectance = D3DXVECTOR3( 0.91f, 0.88f, 0.76f );
D3DXVECTOR3 g_vEta = D3DXVECTOR3( 1.3f, 1.3f-0.02f, 1.3f+( -0.02f*2.0f ) );
D3DXVECTOR3 g_vEtaInverse = D3DXVECTOR3( 1.0f/1.3f, 1.0f/( 1.3f-0.02f ), 1.0f/( 1.3f+( -0.02f*2.0f ) ) );
D3DXVECTOR3 g_vEtaRsq = D3DXVECTOR3( ( 1.0f/1.3f )*( 1.0f/1.3f ), ( 1.0f/( 1.3f-0.02f ) )*( 1.0f/( 1.3f-0.02f ) ), ( 1.0f/( 1.3f+( -0.02f*2.0f ) ) )*( 1.0f/( 1.3f+( -0.02f*2.0f ) ) ) );


//--------------------------------------------------------------------------------------
// UI control IDs
//--------------------------------------------------------------------------------------
#define IDC_TOGGLEFULLSCREEN 1
#define IDC_TOGGLEREF 2
#define IDC_CHANGEDEVICE 3


//--------------------------------------------------------------------------------------
// Function declarations 
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext );
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext );
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pD3DDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext );
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pD3DDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext );
void CALLBACK OnFrameMove( IDirect3DDevice9* pD3DDevice, double fTime, float fElapsedTime, void* pUserContext );
void CALLBACK OnFrameRender( IDirect3DDevice9* pD3DDevice, double fTime, float fElapsedTime, void* pUserContext );
LRESULT CALLBACK OnMsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing, void* pUserContext );
void CALLBACK OnKeyboardProc( UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext );
void CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext );
void CALLBACK OnLostDevice( void* pUserContext );
void CALLBACK OnDestroyDevice( void* pUserContext );

void InitApp( );
void CaptureScreen( void );


//--------------------------------------------------------------------------------------
// Entry point to the program. Initializes everything and goes into a message processing 
// loop. Idle time is used to render the scene.
//--------------------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int )
{
	HRESULT hr;

	// Enable run-time memory check for debug builds.
#if defined( DEBUG ) | defined( _DEBUG )
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

	// Set the callback functions.
	DXUTSetCallbackDeviceCreated( OnCreateDevice );
	DXUTSetCallbackDeviceReset( OnResetDevice );
	DXUTSetCallbackDeviceLost( OnLostDevice );
	DXUTSetCallbackDeviceDestroyed( OnDestroyDevice );
	DXUTSetCallbackMsgProc( OnMsgProc );
	DXUTSetCallbackKeyboard( OnKeyboardProc );
	DXUTSetCallbackFrameRender( OnFrameRender );
	DXUTSetCallbackFrameMove( OnFrameMove );

	// Show the cursor and clip it when in full screen
	DXUTSetCursorSettings( true, true );

	InitApp( );

	V( RenderInit( ) );

	// Initialize DXUT and create the desired Win32 window and Direct3D 
	// device for the application. Calling each of these functions is optional, but they
	// allow you to set several options which control the behavior of the framework.
	DXUTInit( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
	DXUTCreateWindow( L"Real-Time Subsurface Scattering using Shadow Maps, ShaderX7" );
	DXUTCreateDevice( D3DADAPTER_DEFAULT, true, 512, 512, IsDeviceAcceptable, ModifyDeviceSettings );

	// Pass control to DXUT for handling the message pump and 
	// dispatching render calls. DXUT will call your FrameMove 
	// and FrameRender callback when there is idle time between handling window messages.
	DXUTMainLoop( );

	// Perform any application-level cleanup here. Direct3D device resources are released within the
	// appropriate callback functions and therefore don't require any cleanup code here.

	return DXUTGetExitCode( );
}


//--------------------------------------------------------------------------------------
// Initialize the app 
//--------------------------------------------------------------------------------------
void InitApp( )
{
	WCHAR buff[256];

	// Initialize dialogs
	g_SettingsDlg.Init( &g_DialogResourceManager );
	g_HUD.Init( &g_DialogResourceManager );
	g_SampleUI1.Init( &g_DialogResourceManager );
	g_SampleUI2.Init( &g_DialogResourceManager );

	g_SampleUI1.SetFont( 0, L"Tahoma", 12, 1 );
	g_SampleUI2.SetFont( 0, L"Tahoma", 12, 1 );

	g_HUD.SetCallback( OnGUIEvent ); 
	
	int iY = 10; 
	g_HUD.AddButton( IDC_TOGGLEFULLSCREEN, L"Toggle full screen", 35, iY, 125, 22 );
	//HUD.AddButton( IDC_TOGGLEREF, L"Toggle REF ( F3 )", 35, iY += 24, 125, 22 );
	//g_HUD.AddButton( IDC_CHANGEDEVICE, L"Change device ( F2 )", 35, iY += 24, 125, 22, VK_F2 );

	g_SampleUI1.SetCallback( OnGUIEvent );

	iY = 175;

	g_SampleUI1.AddStatic( 33, L"Mouse: left ( camera ), right ( light )", -50, iY, 200, 22 );

	StringCchPrintf( buff, 256, L"Kd ( %.2f )", g_fLocalDiffuse );
	g_SampleUI1.AddStatic( 30, buff, -50, iY += 24, 100, 22 );
	g_SampleUI1.AddSlider( 20, 50, iY, 100, 22 );
	g_SampleUI1.GetSlider( 20 )->SetRange( 0, 200 );
	g_SampleUI1.GetSlider( 20 )->SetValue( g_fLocalDiffuse*50.0f );

	StringCchPrintf( buff, 256, L"Ks ( %.2f )", g_fLocalSpecular );
	g_SampleUI1.AddStatic( 130, buff, -50, iY += 24, 100, 22 );
	g_SampleUI1.AddSlider( 120, 50, iY, 100, 22 );
	g_SampleUI1.GetSlider( 120 )->SetRange( 0, 200 );
	g_SampleUI1.GetSlider( 120 )->SetValue( g_fLocalSpecular*50.0f );

	StringCchPrintf( buff, 256, L"Kss ( %.2f )", g_fSingleScattering );
	g_SampleUI1.AddStatic( 131, buff, -50, iY += 24, 100, 22 );
	g_SampleUI1.AddSlider( 121, 50, iY, 100, 22 );
	g_SampleUI1.GetSlider( 121 )->SetRange( 0, 200 );
	g_SampleUI1.GetSlider( 121 )->SetValue( g_fSingleScattering*50.0f );

	StringCchPrintf( buff, 256, L"rotate ( %.2f )", g_fRotation );
	g_SampleUI1.AddStatic( 35, buff, -50, iY += 24, 100, 22 );
	g_SampleUI1.AddSlider( 25, 50, iY, 100, 22 );
	g_SampleUI1.GetSlider( 25 )->SetRange( 0, 100 );
	g_SampleUI1.GetSlider( 25 )->SetValue( g_fRotation );	


	iY += 80;

	g_SampleUI1.AddComboBox( 40, -40, iY - 480, 200, 24 );
	g_SampleUI1.GetComboBox( 40 )->AddItem( L"tweety", ( void* )0 );
	g_SampleUI1.GetComboBox( 40 )->AddItem( L"big ear", ( void* )1 );
	g_SampleUI1.GetComboBox( 40 )->AddItem( L"stanford bunny", ( void* )2 );
	g_SampleUI1.GetComboBox( 40 )->AddItem( L"femail head", ( void* )3 );
	g_SampleUI1.GetComboBox( 40 )->AddItem( L"maxplanck", ( void* )4 );
	g_SampleUI1.GetComboBox( 40 )->AddItem( L"bigguy", ( void* )5 );
	g_SampleUI1.GetComboBox( 40 )->SetSelectedByIndex( g_nScene );

	g_SampleUI1.AddComboBox( 41, -40, iY - 480 + 24, 200, 24 );
	g_SampleUI1.GetComboBox( 41 )->AddItem( L"final image", ( void* )0 );
	g_SampleUI1.GetComboBox( 41 )->AddItem( L"irradiance", ( void* )1 );
	g_SampleUI1.GetComboBox( 41 )->AddItem( L"lightView position", ( void* )2 );
	g_SampleUI1.GetComboBox( 41 )->AddItem( L"lightView medium id", ( void* )3 );
	g_SampleUI1.GetComboBox( 41 )->AddItem( L"lightView normal", ( void* )4 );
	g_SampleUI1.GetComboBox( 41 )->AddItem( L"light depth", ( void* )5 );

	g_SampleUI1.AddCheckBox( 50, L"always update buffers", 30, iY - 480 + 48, 250, 22 );



	g_SampleUI2.SetCallback( OnGUIEvent );	

	iY = 100;
	g_SampleUI2.AddComboBox( 60, 10, iY += 24, 160, 22 );
	g_SampleUI2.GetComboBox( 60 )->AddItem( L"skimmilk", ( void* ) 0 );
	g_SampleUI2.GetComboBox( 60 )->AddItem( L"apple", ( void* ) 1 );
	g_SampleUI2.GetComboBox( 60 )->AddItem( L"potato", ( void* ) 2 );
	g_SampleUI2.GetComboBox( 60 )->AddItem( L"marble", ( void* ) 3 );
	g_SampleUI2.GetComboBox( 60 )->AddItem( L"synthetic (half albedo)", ( void* ) 4 );
	g_SampleUI2.GetComboBox( 60 )->SetSelectedByIndex( g_nMaterialType );

	StringCchPrintf( buff, 256, L"thick ( %.2f )", g_fOpticalScaling );
	g_SampleUI2.AddStatic( 37, buff, -15, iY += 24, 100, 22 );
	g_SampleUI2.AddSlider( 27, 65, iY, 100, 22 );
	g_SampleUI2.GetSlider( 27 )->SetRange( 0, 200 );
	g_SampleUI2.GetSlider( 27 )->SetValue( g_fOpticalScaling );	

	StringCchPrintf( buff, 256, L"bias ( %.2f )", g_fOpticalBias );
	g_SampleUI2.AddStatic( 39, buff, -15, iY += 24, 100, 22 );
	g_SampleUI2.AddSlider( 29, 65, iY, 100, 22 );
	g_SampleUI2.GetSlider( 29 )->SetRange( 0, 100 );
	g_SampleUI2.GetSlider( 29 )->SetValue( g_fOpticalBias );	

	StringCchPrintf( buff, 256, L"samples ( %d )", g_nSamples );
	g_SampleUI2.AddStatic( 138, buff, -15, iY += 24, 100, 22 );
	g_SampleUI2.AddSlider( 128, 65, iY, 100, 22 );
	g_SampleUI2.GetSlider( 128 )->SetRange( 5, 100 );
	g_SampleUI2.GetSlider( 128 )->SetValue( g_nSamples );

	StringCchPrintf( buff, 256, L"g ( %.2f )", g_fMeanCosineAngle );
	g_SampleUI2.AddStatic( 34, buff, -15, iY += 24, 100, 22 );
	g_SampleUI2.AddSlider( 24, 65, iY, 100, 22 );
	g_SampleUI2.GetSlider( 24 )->SetRange( 0, 100 );
	g_SampleUI2.GetSlider( 24 )->SetValue( g_fMeanCosineAngle * 50.0f + 50.0f );

	StringCchPrintf( buff, 256, L"jitter ( %.2f )", g_fJitter );
	g_SampleUI2.AddStatic( 200, buff, -15, iY += 24, 100, 22 );
	g_SampleUI2.AddSlider( 210, 65, iY, 100, 22 );
	g_SampleUI2.GetSlider( 210 )->SetRange( 0, 100 );
	g_SampleUI2.GetSlider( 210 )->SetValue( g_fJitter * 100.0f );

	StringCchPrintf( buff, 256, L"penum ( %.2f )", g_fPenumbra );
	g_SampleUI2.AddStatic( 201, buff, -15, iY += 24, 100, 22 );
	g_SampleUI2.AddSlider( 211, 65, iY, 100, 22 );
	g_SampleUI2.GetSlider( 211 )->SetRange( 20, 100 );
	g_SampleUI2.GetSlider( 211 )->SetValue( g_fPenumbra * 100.0f );


	// initialize
	OnGUIEvent( 0, 0, NULL, NULL );
}


//--------------------------------------------------------------------------------------
// Called during device initialization, this code checks the device for some 
// minimum set of capabilities, and rejects those that don't pass by returning false.
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, 
								 D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
	// Skip backbuffer formats that don't support alpha blending
	IDirect3D9* pD3D = DXUTGetD3DObject( ); 
	if ( FAILED( pD3D->CheckDeviceFormat( pCaps->AdapterOrdinal, pCaps->DeviceType,
		AdapterFormat, D3DUSAGE_QUERY_POSTPIXELSHADER_BLENDING, 
		D3DRTYPE_TEXTURE, BackBufferFormat ) ) )
		return false;

	return true;
}


//--------------------------------------------------------------------------------------
// This callback function is called immediately before a device is created to allow the 
// application to modify the device settings.
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext )
{
	// For the first device created if its a REF device, optionally display a warning dialog box
	static bool s_bFirstTime = true;
	if ( s_bFirstTime )
	{
		s_bFirstTime = false;
		if ( pDeviceSettings->DeviceType == D3DDEVTYPE_REF )
			DXUTDisplaySwitchingToREFWarning( );
	}

	// Turn off VSynch
	pDeviceSettings->pp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;

	// multi-sampling
// 	if ( pDeviceSettings->DeviceType == D3DDEVTYPE_HAL )
// 	{
// 		pDeviceSettings->pp.SwapEffect = D3DSWAPEFFECT_DISCARD;
// 		pDeviceSettings->pp.MultiSampleType = D3DMULTISAMPLE_4_SAMPLES;
// 		pDeviceSettings->pp.MultiSampleQuality = 2;
// 	}

	return true;
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has been 
// created, which will happen during application initialization and windowed/full screen toggles. 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pD3DDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;

	g_pD3DDevice = pD3DDevice;

	V_RETURN( g_DialogResourceManager.OnCreateDevice( pD3DDevice ) );
	V_RETURN( g_SettingsDlg.OnCreateDevice( pD3DDevice ) );

	// Initialize the font
	V_RETURN( D3DXCreateFont( pD3DDevice, 12, 0, FW_NORMAL, 1, FALSE, DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, 
		L"Tahoma", &g_pFont ) );

	// Create the effect
	DWORD dwShaderFlags = 0;
	dwShaderFlags |= D3DXSHADER_PREFER_FLOW_CONTROL;
	//dwShaderFlags |= D3DXSHADER_USE_LEGACY_D3DX9_31_DLL;
	//dwShaderFlags |= D3DXSHADER_PARTIALPRECISION;
	V( D3DXCreateEffectFromFile( pD3DDevice, L"FX/SSM.fx", NULL, NULL, dwShaderFlags, NULL, &g_pEffect, NULL ) );

	// Setup the camera's view parameters
	D3DXVECTOR3 vecEye( 15.0f, 15.0f, 15.0f );
	D3DXVECTOR3 vecAt ( 0.0f, 0.0f, 0.0f );
	g_Camera.SetViewParams( &vecEye, &vecAt );

	// Setup the lights
	D3DXVECTOR3 vecLight ( 12.0f, 19.0f, 1.0f );
	D3DXVECTOR3 vecAtLight ( 0.0f, -0.0f, -0.0f );
	g_Light.SetViewParams( &vecLight, &vecAtLight );

	if ( RenderCreateResource( pD3DDevice ) != 0 )
		return -1;

	return S_OK;
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has been 
// reset, which will happen after a lost device scenario. This is the best location to 
// create D3DPOOL_DEFAULT resources since these resources need to be reloaded whenever 
// the device is lost. Resources created here should be released in the OnLostDevice callback. 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pD3DDevice, 
							   const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;

	V_RETURN( g_DialogResourceManager.OnResetDevice( ) );
	V_RETURN( g_SettingsDlg.OnResetDevice( ) );

	if ( g_pFont )
		V_RETURN( g_pFont->OnResetDevice( ) );
	if ( g_pEffect )
		V_RETURN( g_pEffect->OnResetDevice( ) );

	// Create a sprite to help batch calls when drawing many lines of text
	V_RETURN( D3DXCreateSprite( pD3DDevice, &g_pTextSprite ) );

	// Setup the camera's projection parameters
	float fAspectRatio = pBackBufferSurfaceDesc->Width / ( FLOAT )pBackBufferSurfaceDesc->Height;
	//	g_Camera.SetProjParams( D3DX_PI/4, fAspectRatio, 3.0f, 50.0f );
	g_Camera.SetProjParams( D3DX_PI/4.0f, fAspectRatio, 2.0f, 5000.0f );
	g_Camera.SetWindow( pBackBufferSurfaceDesc->Width, pBackBufferSurfaceDesc->Height );
	g_Camera.SetButtonMasks( 1, 8, 0 );

	g_Light.SetProjParams( D3DX_PI/4.0f, 1.0f, 2.0f, 1000.0f );
	g_Light.SetWindow( pBackBufferSurfaceDesc->Width, pBackBufferSurfaceDesc->Height );
	g_Light.SetButtonMasks( 0, 0, 4 );

	g_HUD.SetLocation( pBackBufferSurfaceDesc->Width-170, 0 );
	g_HUD.SetSize( 170, 170 );
	g_SampleUI1.SetLocation( pBackBufferSurfaceDesc->Width-170, pBackBufferSurfaceDesc->Height-350 );
	g_SampleUI1.SetSize( 170, 300 );
	g_SampleUI2.SetLocation( 0, pBackBufferSurfaceDesc->Height-300 );
	g_SampleUI2.SetSize( 170, 300 );

	if ( RenderResetResource( pD3DDevice ) != 0 )
		return -1;

	return S_OK;
}


//--------------------------------------------------------------------------------------
// This callback function will be called once at the beginning of every frame. This is the
// best location for your application to handle updates to the scene, but is not 
// intended to contain actual rendering calls, which should instead be placed in the OnFrameRender callback. 
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( IDirect3DDevice9* pD3DDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	// Update the camera's position based on user input 
	g_Camera.FrameMove( fElapsedTime );
	
	g_Light.FrameMove( fElapsedTime );

	RenderFrameMove( pD3DDevice, fTime, fElapsedTime );
}


//--------------------------------------------------------------------------------------
// This callback function will be called at the end of every frame to perform all the 
// rendering calls for the scene, and it will also be called if the window needs to be 
// repainted. After this function has returned, DXUT will call 
// IDirect3DDevice9::Present to display the contents of the next buffer in the swap chain
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameRender( IDirect3DDevice9* pD3DDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	// set uniforms
	g_pEffect->SetFloat( "g_fLocalDiffuse", g_fLocalDiffuse );
	g_pEffect->SetFloat( "g_fLocalSpecular", g_fLocalSpecular );
	g_pEffect->SetFloat( "g_fSingleScattering", g_fSingleScattering * 20.0f );

	g_pEffect->SetFloat( "g_fOpticalScaling", g_fOpticalScaling );
	g_pEffect->SetFloat( "g_fOpticalBias", g_fOpticalBias );
	g_pEffect->SetFloat( "g_fMeanCosineAngle", g_fMeanCosineAngle );	
	g_pEffect->SetInt( "g_nSamples", g_nSamples );
	g_pEffect->SetFloat( "g_fJitter", g_fJitter );	
	g_pEffect->SetFloat( "g_fPenumbra", g_fPenumbra );		

//	g_pEffect->CommitChanges( );

	// rendering with effects
	RenderFrameRender( pD3DDevice, fTime, fElapsedTime );
}


//--------------------------------------------------------------------------------------
// Render the help and statistics text. This function uses the ID3DXFont interface for 
// efficient text rendering.
//--------------------------------------------------------------------------------------
void RenderText( )
{
	// The helper object simply helps keep track of text position, and color
	// and then it calls pFont->DrawText( m_pSprite, strMsg, -1, &rc, DT_NOCLIP, m_clr );
	// If NULL is passed in as the sprite object, then it will work however the 
	// pFont->DrawText( ) will not be batched together. Batching calls will improves performance.
	CDXUTTextHelper txtHelper( g_pFont, g_pTextSprite, 15 );

	// Output statistics
	txtHelper.Begin( );
	txtHelper.SetInsertionPos( 5, 5 );
	txtHelper.SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 0.0f, 1.0f ) );
	txtHelper.DrawTextLine( DXUTGetFrameStats( ) );

//	WCHAR buff[256];
//
//	StringCchPrintf( buff, 256, L"camera: ( %.2f, %.2f, %.2f ), ( %.2f, %.2f, %.2f )", 
//		g_Camera.GetEyePt( )->x, g_Camera.GetEyePt( )->y, g_Camera.GetEyePt( )->z,
//		g_Camera.GetLookAtPt( )->x, g_Camera.GetLookAtPt( )->y, g_Camera.GetLookAtPt( )->z );
//	txtHelper.DrawTextLine( buff );
//
//	StringCchPrintf( buff, 256, L"light %d: ( %.2f, %.2f, %.2f ), ( %.2f, %.2f, %.2f )", 
//		g_nActiveLight,
//		g_Light[g_nActiveLight].GetEyePt( )->x, g_Light[g_nActiveLight].GetEyePt( )->y, g_Light[g_nActiveLight].GetEyePt( )->z,
//		g_Light[g_nActiveLight].GetLookAtPt( )->x, g_Light[g_nActiveLight].GetLookAtPt( )->y, g_Light[g_nActiveLight].GetLookAtPt( )->z );
//	txtHelper.DrawTextLine( buff );	

	txtHelper.End( );
}


//--------------------------------------------------------------------------------------
// Before handling window messages, DXUT passes incoming windows 
// messages to the application through this callback function. If the application sets 
// *pbNoFurtherProcessing to TRUE, then DXUT will not process this message.
//--------------------------------------------------------------------------------------
LRESULT CALLBACK OnMsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing, void* pUserContext )
{
	// Always allow dialog resource manager calls to handle global messages
	// so GUI state is updated correctly
	g_DialogResourceManager.OnMsgProc( hWnd, uMsg, wParam, lParam );

	if ( g_SettingsDlg.IsActive( ) )
	{
		g_SettingsDlg.OnMsgProc( hWnd, uMsg, wParam, lParam );
		return 0;
	}

	// Give the dialogs a chance to handle the message first
	*pbNoFurtherProcessing = g_HUD.OnMsgProc( hWnd, uMsg, wParam, lParam );
	if ( *pbNoFurtherProcessing )
		return 0;
	*pbNoFurtherProcessing = g_SampleUI1.OnMsgProc( hWnd, uMsg, wParam, lParam );
	if ( *pbNoFurtherProcessing )
		return 0;
	*pbNoFurtherProcessing = g_SampleUI2.OnMsgProc( hWnd, uMsg, wParam, lParam );
	if ( *pbNoFurtherProcessing )
		return 0;

	// Pass all remaining windows messages to camera so it can respond to user input
	g_Camera.HandleMessages( hWnd, uMsg, wParam, lParam );
	g_Light.HandleMessages( hWnd, uMsg, wParam, lParam );

	return 0;
}


//--------------------------------------------------------------------------------------
// As a convenience, DXUT inspects the incoming windows messages for
// keystroke messages and decodes the message parameters to pass relevant keyboard
// messages to the application. The framework does not remove the underlying keystroke 
// messages, which are still passed to the application's OnMsgProc callback.
//--------------------------------------------------------------------------------------
void CALLBACK OnKeyboardProc( UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext )
{
	if ( bKeyDown )
	{
		switch( nChar )
		{
		case VK_F1: g_bShowHelp = !g_bShowHelp; break;
		case VK_F5: g_bShowUI = !g_bShowUI; break;

		case VK_F10:	 CaptureScreen( ); break;

		case VK_F12: DXUTToggleFullScreen( ); break;

		case 'L':
			g_bToggleLightMoving = !g_bToggleLightMoving;
			
			if ( g_bToggleLightMoving )
			{
				g_Light.SetButtonMasks( 0, 8, 4 );
				g_Camera.SetButtonMasks( 1, 0, 0 );
			}
			else
			{
				g_Light.SetButtonMasks( 0, 0, 4 );
				g_Camera.SetButtonMasks( 1, 8, 0 );
			}
			break;
		}
	}
}


//--------------------------------------------------------------------------------------
// Handles the GUI events
//--------------------------------------------------------------------------------------
void CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext )
{
	WCHAR buff[256];

	g_fLocalDiffuse = ( float )( g_SampleUI1.GetSlider( 20 )->GetValue( ) * 0.01f );
	StringCchPrintf( buff, 256, L"Kd ( %.2f )", g_fLocalDiffuse );
	g_SampleUI1.GetStatic( 30 )->SetText( buff );

	g_fLocalSpecular = ( float )( g_SampleUI1.GetSlider( 120 )->GetValue( ) * 0.01f );
	StringCchPrintf( buff, 256, L"Ks ( %.2f )", g_fLocalSpecular );
	g_SampleUI1.GetStatic( 130 )->SetText( buff );

	g_fSingleScattering = ( float )( g_SampleUI1.GetSlider( 121 )->GetValue( ) * 0.01f );
	StringCchPrintf( buff, 256, L"Kss ( %.2f )", g_fSingleScattering );
	g_SampleUI1.GetStatic( 131 )->SetText( buff );	

	g_fRotation = ( float )( g_SampleUI1.GetSlider( 25 )->GetValue( ) * 0.02f * 3.141593f );
	StringCchPrintf( buff, 256, L"rotate ( %.2f )", g_fRotation*3.14195 );
	g_SampleUI1.GetStatic( 35 )->SetText( buff );

	g_fOpticalScaling = ( float )( g_SampleUI2.GetSlider( 27 )->GetValue( ) * 0.1f );
	StringCchPrintf( buff, 256, L"thick ( %.2f )", g_fOpticalScaling );
	g_SampleUI2.GetStatic( 37 )->SetText( buff );

	g_fOpticalBias = ( ( float )( g_SampleUI2.GetSlider( 29 )->GetValue( ) )*0.02f );
	StringCchPrintf( buff, 256, L"bias ( %.2f )", ( ( float ) g_fOpticalBias ) );
	g_SampleUI2.GetStatic( 39 )->SetText( buff );

	g_nSamples = g_SampleUI2.GetSlider( 128 )->GetValue( );
	StringCchPrintf( buff, 256, L"samples ( %d )", g_nSamples );
	g_SampleUI2.GetStatic( 138 )->SetText( buff );

	g_fMeanCosineAngle = ( float( g_SampleUI2.GetSlider( 24 )->GetValue( ) ) - 50.0f ) / 50.0f;
	StringCchPrintf( buff, 256, L"g ( %.2f )", g_fMeanCosineAngle );
	g_SampleUI2.GetStatic( 34 )->SetText( buff );

	g_fJitter = ( float( g_SampleUI2.GetSlider( 210 )->GetValue( ) ) * 0.01f );
	StringCchPrintf( buff, 256, L"jitter ( %.2f )", g_fJitter );
	g_SampleUI2.GetStatic( 200 )->SetText( buff );

	g_fPenumbra = ( float( g_SampleUI2.GetSlider( 211 )->GetValue( ) ) * 0.01f );
	StringCchPrintf( buff, 256, L"penum ( %.2f )", g_fPenumbra );
	g_SampleUI2.GetStatic( 201 )->SetText( buff );

	g_bAlwaysUpdate = ( bool )g_SampleUI1.GetCheckBox( 50 )->GetChecked( );

	// no need to care of 64-bit pointers here...
	g_nScene = ( int )g_SampleUI1.GetComboBox( 40 )->GetSelectedData( );
	g_nDebugTexture = ( int )g_SampleUI1.GetComboBox( 41 )->GetSelectedData( );


	switch( nControlID )
	{
	case IDC_TOGGLEFULLSCREEN: DXUTToggleFullScreen( ); break;
//	case IDC_TOGGLEREF: DXUTToggleREF( ); break;
//	case IDC_CHANGEDEVICE: g_SettingsDlg.SetActive( !g_SettingsDlg.IsActive( ) ); break;

		// material
	case 60:
		{
			g_nMaterialType = ( int ) g_SampleUI2.GetComboBox( 60 )->GetSelectedData( );
		}
		break;
	}
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has 
// entered a lost state and before IDirect3DDevice9::Reset is called. Resources created
// in the OnResetDevice callback should be released here, which generally includes all 
// D3DPOOL_DEFAULT resources. See the "Lost Devices" section of the documentation for 
// information about lost devices.
//--------------------------------------------------------------------------------------
void CALLBACK OnLostDevice( void* pUserContext )
{
	g_DialogResourceManager.OnLostDevice( );
	g_SettingsDlg.OnLostDevice( );
	if ( g_pFont )
		g_pFont->OnLostDevice( );
	if ( g_pEffect )
		g_pEffect->OnLostDevice( );
	SAFE_RELEASE( g_pTextSprite );

	RenderLostResource( );
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has 
// been destroyed, which generally happens as a result of application termination or 
// windowed/full screen toggles. Resources created in the OnCreateDevice callback 
// should be released here, which generally includes all D3DPOOL_MANAGED resources. 
//--------------------------------------------------------------------------------------
void CALLBACK OnDestroyDevice( void* pUserContext )
{
	g_DialogResourceManager.OnDestroyDevice( );
	g_SettingsDlg.OnDestroyDevice( );
	SAFE_RELEASE( g_pEffect );
	SAFE_RELEASE( g_pFont );

	RenderDestroyResource( );
}


//--------------------------------------------------------------------------------------
// Capture frame buffer to a image file.
//--------------------------------------------------------------------------------------
void CaptureScreen( void )
{
	HRESULT hr;

	LPDIRECT3DSURFACE9 lpBackBuffer;
	V( g_pD3DDevice->GetRenderTarget( 0, &lpBackBuffer ) );

	WCHAR buff[100];
	FILE *file = NULL;
	for ( int i = 0; i < 1000; ++i )
	{
		StringCchPrintf( buff, 100, L"Screenshot\\Shot%d.png", i );

		file = _wfopen( buff, L"r" );
		if ( file == NULL )
		{
			break;
		}
		fclose( file );
	}

	if ( file != NULL )
		fclose( file );

	D3DXSaveSurfaceToFile( buff, D3DXIFF_PNG, lpBackBuffer, NULL, NULL );
	SAFE_RELEASE( lpBackBuffer );
}