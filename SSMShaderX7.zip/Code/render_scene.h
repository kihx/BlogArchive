
typedef struct
{
	float x, y, z, u, v;
} TEXTUREDVERTEX;

const TEXTUREDVERTEX g_ScreenQuad[] =
{
	{ -1, -1, 0, 0, 1 },
	{ -1, 1, 0, 0, 0 },
	{ 1, -1, 0, 1, 1 },
	{ 1, 1, 0, 1, 0 },
};

D3DXVECTOR4 g_vEyePosition;
D3DXVECTOR4 g_vLightPosition;

static int g_nLastSampleCount = -1;
static int g_bUpdateCamera = 1, g_bUpdateSSM = 1;
static float g_fLastRotation = 1e30f;
static int g_nLastScene = -1;


void CheckPositionUpdates( )
{
	extern bool g_bAlwaysUpdate;
	extern int g_nScene;
	extern float g_fRotation;

	extern CModelViewerCamera g_Light;
	extern CModelViewerCamera g_Camera;

	if ( g_bAlwaysUpdate || g_Camera.IsBeingDragged( ) || g_fLastRotation != g_fRotation || g_nLastScene != g_nScene )
	{
		g_bUpdateCamera = true;
	}

	if ( g_bAlwaysUpdate || g_Light.IsBeingDragged( ) || g_fLastRotation != g_fRotation || g_nLastScene != g_nScene )
	{
		g_bUpdateSSM = true;
	}

	g_fLastRotation = g_fRotation;
	g_nLastScene = g_nScene;
}

// callback to set diffuse colors to shader constants ( when drawing OBJs )
void MaterialCallback( void *pMatPtr )
{
	OBJMaterial* pObjMat = ( OBJMaterial* ) pMatPtr;
	if ( pObjMat == NULL )
		return;

	if ( pObjMat->pTexture != NULL )
		g_pEffect->SetTexture( "COLORTEX", pObjMat->pTexture );

	g_pEffect->CommitChanges( );
}

// render screen aligned quad
void RenderScreenQuad( IDirect3DDevice9* pD3DDevice )
{
	pD3DDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );

	pD3DDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, g_ScreenQuad, sizeof( TEXTUREDVERTEX ) );
}

// setup all matrices for light and camera view
void SetMatrixForModel( D3DXMATRIX modelMatrix )
{
	extern CModelViewerCamera g_Light;;
	extern CModelViewerCamera g_Camera;

	// light
	g_vLightPosition = D3DXVECTOR4( *g_Light.GetEyePt( ), 1.0f );
	g_pEffect->SetVector( "g_vLightPosition", &g_vLightPosition );

	D3DXMATRIX matViewLight = *g_Light.GetWorldMatrix( ) * *g_Light.GetViewMatrix( );
	D3DXMATRIX matWorldLight = modelMatrix;
	D3DXMATRIX matProjectionLight = *g_Light.GetProjMatrix( );
	//D3DXMatrixOrthoLH( &matProjectionLight, 16, 16, 2, 1000 );	// for directional light
	D3DXMATRIX modelViewProjectionLight = matWorldLight * matViewLight * matProjectionLight;
	D3DXMATRIX matViewProjectionLight = matViewLight * matProjectionLight;

	g_pEffect->SetMatrix( "g_mWLight", &matWorldLight );
	g_pEffect->SetMatrix( "g_mVPLight", &matViewProjectionLight );
	g_pEffect->SetMatrix( "g_mWVPLight", &modelViewProjectionLight );


	// camera
	g_vEyePosition = D3DXVECTOR4( *g_Camera.GetEyePt( ), 1.0f );
	g_pEffect->SetVector( "g_vEyePosition", &g_vEyePosition );


	D3DXMATRIX matWorld = modelMatrix;
	D3DXMATRIX matView = *g_Camera.GetWorldMatrix( ) * *g_Camera.GetViewMatrix( );
	D3DXMATRIX matProjection = *g_Camera.GetProjMatrix( );
	D3DXMATRIX matWorldView = matWorld * matView;
	D3DXMATRIX modelViewProjection = matWorldView * matProjection;
	g_pEffect->SetMatrix( "g_mW", &matWorld );
	g_pEffect->SetMatrix( "g_mWVP", &modelViewProjection );
}

// renders the scene, as seen from the lightsource
void RenderSceneLightView( IDirect3DDevice9* pD3DDevice )
{
	extern float g_fRotation;

	UINT nPasses;

	D3DXMATRIX modelRotate;
	D3DXMatrixIdentity( &modelRotate );

	D3DXMATRIX m0;
	D3DXMatrixIdentity( &m0 );

	D3DXMATRIX m1;
	D3DXMatrixIdentity( &m1 );

	D3DXMATRIX m2;
	D3DXMatrixIdentity( &m2 );

	if ( g_objBG )
	{
		g_pEffect->Begin( &nPasses, 0 );
	
		SetMatrixForModel( m0 );

		g_pEffect->SetFloat( "g_fMaterialID", 0.1f );
        
		for ( UINT p = 0; p < nPasses; p++ )
		{
			g_pEffect->BeginPass( p );
			g_OpticalProperties[6].Commit( g_pEffect );
			g_pEffect->CommitChanges( );
			g_objBG->drawModel( pD3DDevice, MaterialCallback );
			g_pEffect->EndPass( );
		}

		g_pEffect->End( );
	}

	if ( g_objModel )
	{

		D3DXMatrixRotationY( &modelRotate, g_fRotation );
		m1 = modelRotate * m1;
		SetMatrixForModel( m1 );

		g_pEffect->SetFloat( "g_fMaterialID", 0.3f );

		g_pEffect->Begin( &nPasses, 0 );

		SetMatrixForModel( m1 );

		for ( UINT p = 0; p < nPasses; p++ )
		{
			g_pEffect->BeginPass( p );
			g_OpticalProperties[g_nMaterialType].Commit( g_pEffect );
			g_pEffect->CommitChanges( );
			g_objModel->drawModel( pD3DDevice, MaterialCallback );
			g_pEffect->EndPass( );
		}

		g_pEffect->End( );
	}

	if ( g_bAnimation )
	{
		g_pEffect->SetFloat( "g_fMaterialID", 0.6f );

		g_pEffect->Begin( &nPasses, 0 );

		SetMatrixForModel( m2 );

		for ( UINT p = 0; p < nPasses; p++ )
		{
			g_pEffect->BeginPass( p );
			g_OpticalProperties[g_nMaterialType].Commit( g_pEffect );
			g_pEffect->CommitChanges( );
			g_objAnimation[g_nCurrentFrame]->drawModel( pD3DDevice, MaterialCallback );
			g_pEffect->EndPass( );
		}

		g_pEffect->End( );
	}
}


// renders the scene camera view
void	RenderScene( IDirect3DDevice9* pD3DDevice )
{
	extern float g_fRotation;

	UINT nPasses;

	D3DXMATRIX modelRotate;
	D3DXMatrixIdentity( &modelRotate );

	D3DXMATRIX m0;
	D3DXMatrixIdentity( &m0 );

	D3DXMATRIX m1;
	D3DXMatrixIdentity( &m1 );

	D3DXMATRIX m2;
	D3DXMatrixIdentity( &m2 );

	if ( g_objBG )
	{
		g_pEffect->Begin( &nPasses, 0 );

		SetMatrixForModel( m0 );

		g_pEffect->SetFloat( "g_fMaterialID", 0.1f );

		for ( UINT p = 0; p < nPasses; p++ )
		{
			g_pEffect->BeginPass( p );
			g_OpticalProperties[6].Commit( g_pEffect );
			g_pEffect->CommitChanges( );
			g_objBG->drawModel( pD3DDevice, MaterialCallback );
			g_pEffect->EndPass( );
		}

		g_pEffect->End( );
	}

	if ( g_objModel )
	{

		D3DXMatrixRotationY( &modelRotate, g_fRotation );
		m1 = modelRotate * m1;
		SetMatrixForModel( m1 );

		g_pEffect->SetFloat( "g_fMaterialID", 0.3f );

		g_pEffect->Begin( &nPasses, 0 );

		SetMatrixForModel( m1 );

		for ( UINT p = 0; p < nPasses; p++ )
		{
			g_pEffect->BeginPass( p );
			g_OpticalProperties[g_nMaterialType].Commit( g_pEffect );
			g_pEffect->CommitChanges( );
			g_objModel->drawModel( pD3DDevice, MaterialCallback );
			g_pEffect->EndPass( );
		}

		g_pEffect->End( );
	}

	if ( g_bAnimation )
	{
		g_pEffect->SetFloat( "g_fMaterialID", 0.6f );

		g_pEffect->Begin( &nPasses, 0 );

		SetMatrixForModel( m2 );

		for ( UINT p = 0; p < nPasses; p++ )
		{
			g_pEffect->BeginPass( p );
			g_OpticalProperties[g_nMaterialType].Commit( g_pEffect );
			g_pEffect->CommitChanges( );
			g_objAnimation[g_nCurrentFrame]->drawModel( pD3DDevice, MaterialCallback );
			g_pEffect->EndPass( );
		}

		g_pEffect->End( );
	}
}

